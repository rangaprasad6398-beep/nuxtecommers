const isOpenImageSliderModal = ref(false);

export const useComponents = () => {
  return {
    isOpenImageSliderModal,
  };
};
